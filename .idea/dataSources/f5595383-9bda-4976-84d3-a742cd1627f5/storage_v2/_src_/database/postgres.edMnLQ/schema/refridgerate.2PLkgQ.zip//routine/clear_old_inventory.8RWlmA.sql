create function clear_old_inventory() returns void
    language plpgsql
as
$$
BEGIN

    DELETE
    FROM Inventory
    WHERE date < (CURRENT_DATE - INTERVAL '3 months');


END;
$$;

alter function clear_old_inventory() owner to postgres;

