create function check_and_clear_old_inventory() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Clean up old records whenever a new inventory record is added/updated
    DELETE FROM refrigderate.inventory
    WHERE date < (CURRENT_DATE - INTERVAL '3 months');

    RETURN NEW;
END;
$$;

alter function check_and_clear_old_inventory() owner to postgres;

