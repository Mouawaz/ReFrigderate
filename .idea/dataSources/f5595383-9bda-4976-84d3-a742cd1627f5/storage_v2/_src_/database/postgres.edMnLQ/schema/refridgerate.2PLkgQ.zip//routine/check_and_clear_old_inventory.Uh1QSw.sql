create function check_and_clear_old_inventory() returns trigger
    language plpgsql
as
$$
BEGIN
    DELETE FROM refridgerate.inventory
    WHERE date < (CURRENT_DATE - INTERVAL '3 months');
    RETURN NEW;
END;
$$;

alter function check_and_clear_old_inventory() owner to postgres;

